#include <iostream>
#include <cstdlib>
#include "prog.h"

using namespace std;
int main()
{
  return 0;
}